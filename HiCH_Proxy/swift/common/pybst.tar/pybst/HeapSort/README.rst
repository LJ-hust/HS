.. -*- mode: rst -*-

About
=====

Heap sort algorithms for python



How to use ?
==============

Declare an object ::

    heap = Heap()
    
Add new values to grown heap tree ::

    heap.add(new values)

call sort algorithm ::

    heap.heap.sort()
    
print result ::
    
    heap.showArray()